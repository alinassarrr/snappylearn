<?php
define("DB_SERVER", "localhost");
define("DB_USER", "id21760709_snappy");
define("DB_PASSWORD", "Ali@000webhost1");
define("DB_DBNAME", "id21760709_snappy");

$mysqli = new mysqli(DB_SERVER, DB_USER, DB_PASSWORD, DB_DBNAME);

// Check connection
if ($mysqli->connect_error) {
    die("Error connecting to the server: " . $mysqli->connect_error);
}

// Optionally, set character set to utf8 (if needed)
if (!$mysqli->set_charset("utf8")) {
    echo "Error setting character set: " . $mysqli->error;
    exit();
}

// You can uncomment the following line if you want to see a success message
// echo "Connected to the database successfully";
?>
