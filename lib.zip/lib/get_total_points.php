<?php
// Include database configuration
require 'config.php';


$userId = $_GET['user_id']; // Change to $_POST if you are using POST method
$courseName = $_GET['course_name']; // Change to $_POST if you are using POST method

// Retrieve total points for the user and course
$retrieveQuery = "SELECT total_points FROM points WHERE user_id = $userId AND course_name = '$courseName'";
$result = $conn->query($retrieveQuery);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $totalPoints = $row['total_points'];
    echo $totalPoints;
} else {
    echo "0"; // Default value if no points are found
}

$conn->close();
?>
