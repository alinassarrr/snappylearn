<?php

include 'config.php';

// Retrieve data from the request
$data = json_decode(file_get_contents('php://input'), true);

$user_id = $data['user_id'];
$course_name = $data['course_name'];

// Use prepared statements to avoid SQL injection
$stmt = $mysqli->prepare("DELETE FROM favorite_courses WHERE user_id = ? AND course_name = ?");

if ($stmt === false) {
    // Handle statement preparation error
    echo "Error preparing statement";
    exit();
}

$stmt->bind_param("ss", $user_id, $course_name);

if ($stmt->execute()) {
    echo "1";  // or any other response indicating success
} else {
    echo "Error executing statement: " . $stmt->error;
}

$stmt->close();

// Close the database connection
$mysqli->close();
?>
