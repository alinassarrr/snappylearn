<?php
// Include database configuration
require 'config.php';

$userId = $_POST['user_id'];
$courseName = $_POST['course_name'];
$points = $_POST['points'];


// Check if user and course entry already exist
$checkQuery = "SELECT * FROM points WHERE user_id = $userId AND course_name = '$courseName'";
$checkResult = $conn->query($checkQuery);

if ($checkResult->num_rows > 0) {
    // User and course entry already exists, update points
    $updateQuery = "UPDATE points SET total_points = total_points + $points WHERE user_id = $userId AND course_name = '$courseName'";
    $conn->query($updateQuery);
} else {
    // User and course entry doesn't exist, insert new entry
    $insertQuery = "INSERT INTO points (user_id, course_name, total_points) VALUES ($userId, '$courseName', $points)";
    $conn->query($insertQuery);
}

$conn->close();
?>
